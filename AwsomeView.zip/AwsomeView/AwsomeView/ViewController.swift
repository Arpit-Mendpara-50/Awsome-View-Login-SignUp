//
//  ViewController.swift
//  AwsomeView
//
//  Created by Arpit on 01/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate  {

    @IBOutlet weak var topViewHeightConstrain: NSLayoutConstraint!
    @IBOutlet weak var heightConstrain: NSLayoutConstraint!
    @IBOutlet weak var intialView: UIView!
    @IBOutlet weak var topViewFirst: UIView!
    @IBOutlet weak var topViewSecond: UIView!
    
    @IBOutlet weak var bottomViewFirst: UIView!
    @IBOutlet weak var bottomViewSecond: UIView!
    
    var newTopViewSecond = UIView()
    var newBottomViewFirst = UIView()
    
    let emailLabel = UILabel()
    let emailTextField = UITextField()
    let passwordLabel = UILabel()
    let passwordTextField = UITextField()
    let loginButton = UIButton()
    let signupButton = UIButton()
    let notUser = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
    
        observeKeyboardNotifications()
        //Keyboard Hide
        emailTextField.delegate = self
        passwordTextField.delegate = self
        intialView.backgroundColor = UIColor.black
        ViewSetup()
        topViewSetup()
        
        signupButton.addTarget(self, action: #selector(signUpButtonPressed(_:)), for: .touchUpInside)
        
        loginButton.addTarget(self, action: #selector(logInButtonPressed(_:)), for: .touchUpInside)
        
        
    }
    //Hide Keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    fileprivate func observeKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    @objc func keyboardHide() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            
            self.heightConstrain.constant = 570
            
        }, completion: nil)
    }
    
    @objc func keyboardShow() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.heightConstrain.constant = 850
            
        }, completion: nil)
    }
    
    func ViewSetup(){
        topViewFirst.clipsToBounds = true
        topViewFirst.layer.cornerRadius = 25
        topViewSecond.clipsToBounds = true
        topViewSecond.layer.cornerRadius = 25
        newTopViewSecond = TopViewCut(frame: topViewSecond.frame)
        newTopViewSecond.clipsToBounds = true
        newTopViewSecond.layer.cornerRadius = 25
        
        bottomViewSecond.clipsToBounds = true
        bottomViewSecond.layer.cornerRadius = 25
        bottomViewFirst.clipsToBounds = true
        bottomViewFirst.layer.cornerRadius = 25
        newBottomViewFirst = BottomViewCut(frame: bottomViewFirst.frame)
        newBottomViewFirst.clipsToBounds = true
        newBottomViewFirst.layer.cornerRadius = 25
    }
    
    func topViewSetup(){
        
        //Email Label
        emailLabel.frame = CGRect(x: 30, y: 40, width: newTopViewSecond.frame.size.width-20, height: 20)
        emailLabel.text = "EMAIL/MOBILE"
        emailLabel.textColor = UIColor.black
        topViewFirst.addSubview(emailLabel)
        
        //Email TextField
        emailTextField.frame = CGRect(x: 30, y: 60, width: newTopViewSecond.frame.size.width-30, height: 40)
        addLineToView(view: emailTextField, position:.LINE_POSITION_BOTTOM, color: UIColor.darkGray, width: 0.5)
        
        let emailImageView = UIImageView();
        let imageEmail = UIImage(named: "Email");
        emailImageView.image = imageEmail;
        
        emailImageView.frame = CGRect(x: 5, y: 10, width: 20, height: 20)
        emailTextField.leftViewMode = UITextField.ViewMode.always
        emailTextField.addSubview(emailImageView)
        
        let emailPaddingView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: self.emailTextField.frame.height))
        emailTextField.leftView = emailPaddingView
        topViewFirst.addSubview(emailTextField)
        
        //Password Label
        passwordLabel.frame = CGRect(x: 30, y: 120, width: newTopViewSecond.frame.size.width-20, height: 20)
        passwordLabel.text = "PASSWORD"
        passwordLabel.textColor = UIColor.black
        topViewFirst.addSubview(passwordLabel)
        
        //Password TextField
        passwordTextField.frame = CGRect(x: 30, y: 150, width: newTopViewSecond.frame.size.width-30, height: 40)
        addLineToView(view: passwordTextField, position:.LINE_POSITION_BOTTOM, color: UIColor.darkGray, width: 0.5)
        
        let passwordImageView = UIImageView();
        let imagePassword = UIImage(named: "Password");
        passwordImageView.image = imagePassword;
        
        passwordImageView.frame = CGRect(x: 5, y: 10, width: 20, height: 20)
        passwordTextField.leftViewMode = UITextField.ViewMode.always
        passwordTextField.addSubview(passwordImageView)
        
        let passwordPaddingView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: self.emailTextField.frame.height))
        passwordTextField.leftView = passwordPaddingView
        topViewFirst.addSubview(passwordTextField)
        
        //Login Button
        let loginImage = UIImage(named: "Login")
        loginButton.frame = CGRect(x: newTopViewSecond.frame.size.width-60, y: newTopViewSecond.frame.size.height-60, width: 50, height: 50)
        loginButton.backgroundColor = UIColor.black
        loginButton.setImage(loginImage, for: .normal)
        loginButton.clipsToBounds = true
        loginButton.layer.cornerRadius = loginButton.frame.width / 2
        newTopViewSecond.addSubview(loginButton)
        
        self.intialView.addSubview(newTopViewSecond)
        
        //Don't have an account label
        notUser.frame = CGRect(x: 20, y: newBottomViewFirst.frame.height-30, width: newBottomViewFirst.frame.width-20, height: 20)
        notUser.textAlignment = .center
        notUser.font = UIFont(name: notUser.font.fontName, size: 14)
        notUser.text = "Don't have an Account"
        notUser.textColor = UIColor.black
        newBottomViewFirst.addSubview(notUser)
        
        //SignUp Button
        signupButton.frame = CGRect(x: 20, y: bottomViewSecond.frame.size.height-60, width: bottomViewSecond.frame.size.width - 40, height: 50)
        signupButton.setTitle("SIGN UP", for: .normal)
        signupButton.backgroundColor = UIColor.black
        signupButton.clipsToBounds = true
        signupButton.layer.cornerRadius = 25
        bottomViewSecond.addSubview(signupButton)
        
        self.intialView.addSubview(newBottomViewFirst)
        
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if UIDevice.current.orientation.isLandscape {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.newTopViewSecond.removeFromSuperview()
                 self.newBottomViewFirst.removeFromSuperview()
                self.ViewSetup()
                self.topViewSetup()
            }
            
        } else {            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.newBottomViewFirst.removeFromSuperview()
                self.newTopViewSecond.removeFromSuperview()
                self.ViewSetup()
                self.topViewSetup()
                
            }
        }
    }
    
    @IBAction func tapGesture(_ sender: UITapGestureRecognizer) {
        if emailTextField.isFirstResponder{
            emailTextField.resignFirstResponder()
        }else{
            passwordTextField.resignFirstResponder()
        }
    }
    
    @objc func signUpButtonPressed(_ sender: UIButton){
        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "Signup") as! SignUpViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func logInButtonPressed(_ sender: UIButton){
    }
    
    

}

enum LINE_POSITION {
    case LINE_POSITION_TOP
    case LINE_POSITION_BOTTOM
}

func addLineToView(view : UIView, position : LINE_POSITION, color: UIColor, width: Double) {
    let lineView = UIView()
    lineView.backgroundColor = color
    lineView.translatesAutoresizingMaskIntoConstraints = false // This is important!
    view.addSubview(lineView)
    
    let metrics = ["width" : NSNumber(value: width)]
    let views = ["lineView" : lineView]
    view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[lineView]|", options:NSLayoutConstraint.FormatOptions(rawValue: 0), metrics:metrics, views:views))
    
    switch position {
    case .LINE_POSITION_TOP:
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[lineView(width)]", options:NSLayoutConstraint.FormatOptions(rawValue: 0), metrics:metrics, views:views))
        break
    case .LINE_POSITION_BOTTOM:
        view.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:[lineView(width)]|", options:NSLayoutConstraint.FormatOptions(rawValue: 0), metrics:metrics, views:views))
        break
    default:
        break
    }
}

extension UIButton{
    
    func setButtonBackground(colorOne: UIColor, colorTwo: UIColor){
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        gradientLayer.colors = [colorOne.cgColor,colorTwo.cgColor]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.startPoint = CGPoint(x: 1.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.0)
        layer.insertSublayer(gradientLayer, at: 0)
    }
}
extension UIView{
    
    func setViewBackground(colorOne: UIColor, colorTwo: UIColor){
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        gradientLayer.colors = [colorOne.cgColor,colorTwo.cgColor]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.startPoint = CGPoint(x: 1.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.0)
        layer.insertSublayer(gradientLayer, at: 0)
    }
}





