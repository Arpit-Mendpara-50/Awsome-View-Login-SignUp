//
//  SignUpViewController.swift
//  AwsomeView
//
//  Created by Arpit on 09/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController , UITextFieldDelegate {

    @IBOutlet weak var topViewHeightConstrain: NSLayoutConstraint!
    @IBOutlet weak var heightConstrain: NSLayoutConstraint!
    @IBOutlet weak var intialView: UIView!
    @IBOutlet weak var topViewFirst: UIView!
    @IBOutlet weak var topViewSecond: UIView!
    
    @IBOutlet weak var bottomViewFirst: UIView!
    @IBOutlet weak var bottomViewSecond: UIView!
    
    var newTopViewSecond = UIView()
    var newBottomViewFirst = UIView()
    
    let NameLabel = UILabel()
    let NameTextField = UITextField()
    let emailLabel = UILabel()
    let emailTextField = UITextField()
    let passwordLabel = UILabel()
    let passwordTextField = UITextField()
    let loginButton = UIButton()
    let signupButton = UIButton()
    let notUser = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        observeKeyboardNotifications()
        //Keyboard Hide
        emailTextField.delegate = self
        passwordTextField.delegate = self
        intialView.backgroundColor = UIColor.black
        ViewSetup()
        topViewSetup()
        
        signupButton.addTarget(self, action: #selector(signUpButtonPressed(_:)), for: .touchUpInside)
        
        loginButton.addTarget(self, action: #selector(logInButtonPressed(_:)), for: .touchUpInside)
    }
    //Hide Keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    fileprivate func observeKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    @objc func keyboardHide() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            
            self.heightConstrain.constant = 670
            
        }, completion: nil)
    }
    
    @objc func keyboardShow() {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.heightConstrain.constant = 850
            
        }, completion: nil)
    }
    
    func ViewSetup(){
        topViewFirst.clipsToBounds = true
        topViewFirst.layer.cornerRadius = 25
        topViewSecond.clipsToBounds = true
        topViewSecond.layer.cornerRadius = 25
        newTopViewSecond = TopViewCut(frame: topViewSecond.frame)
        newTopViewSecond.clipsToBounds = true
        newTopViewSecond.layer.cornerRadius = 25
        
        bottomViewSecond.clipsToBounds = true
        bottomViewSecond.layer.cornerRadius = 25
        bottomViewFirst.clipsToBounds = true
        bottomViewFirst.layer.cornerRadius = 25
        newBottomViewFirst = BottomViewCut(frame: bottomViewFirst.frame)
        newBottomViewFirst.clipsToBounds = true
        newBottomViewFirst.layer.cornerRadius = 25
    }
    
    func topViewSetup(){
        
        //Name Label
        NameLabel.frame = CGRect(x: 30, y: 40, width: newTopViewSecond.frame.size.width-20, height: 20)
        NameLabel.text = "NAME"
        NameLabel.textColor = UIColor.black
        topViewFirst.addSubview(NameLabel)
        
        //Name TextField
        NameTextField.frame = CGRect(x: 30, y: 60, width: newTopViewSecond.frame.size.width-30, height: 40)
        addLineToView(view: NameTextField, position:.LINE_POSITION_BOTTOM, color: UIColor.darkGray, width: 0.5)
        
        let nameImageView = UIImageView();
        let imageName = UIImage(named: "Name");
        nameImageView.image = imageName;
        
        nameImageView.frame = CGRect(x: 5, y: 10, width: 20, height: 20)
        NameTextField.leftViewMode = UITextField.ViewMode.always
        NameTextField.addSubview(nameImageView)
        
        let namePaddingView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: self.NameTextField.frame.height))
        NameTextField.leftView = namePaddingView
        topViewFirst.addSubview(NameTextField)
        
        //Email Label
        emailLabel.frame = CGRect(x: 30, y: 120, width: newTopViewSecond.frame.size.width-20, height: 20)
        emailLabel.text = "EMAIL"
        emailLabel.textColor = UIColor.black
        topViewFirst.addSubview(emailLabel)
        
        //Email TextField
        emailTextField.frame = CGRect(x: 30, y: 140, width: newTopViewSecond.frame.size.width-30, height: 40)
        addLineToView(view: emailTextField, position:.LINE_POSITION_BOTTOM, color: UIColor.darkGray, width: 0.5)
        
        let emailImageView = UIImageView();
        let imageEmail = UIImage(named: "Email");
        emailImageView.image = imageEmail;
        
        emailImageView.frame = CGRect(x: 5, y: 10, width: 20, height: 20)
        emailTextField.leftViewMode = UITextField.ViewMode.always
        emailTextField.addSubview(emailImageView)
        
        let emailPaddingView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: self.emailTextField.frame.height))
        emailTextField.leftView = emailPaddingView
        topViewFirst.addSubview(emailTextField)
        
        //Password Label
        passwordLabel.frame = CGRect(x: 30, y: 200, width: newTopViewSecond.frame.size.width-20, height: 20)
        passwordLabel.text = "PASSWORD"
        passwordLabel.textColor = UIColor.black
        topViewFirst.addSubview(passwordLabel)
        
        //Password TextField
        passwordTextField.frame = CGRect(x: 30, y: 220, width: newTopViewSecond.frame.size.width-30, height: 40)
        addLineToView(view: passwordTextField, position:.LINE_POSITION_BOTTOM, color: UIColor.darkGray, width: 0.5)
        
        let passwordImageView = UIImageView();
        let imagePassword = UIImage(named: "Password");
        passwordImageView.image = imagePassword;
        
        passwordImageView.frame = CGRect(x: 5, y: 10, width: 20, height: 20)
        passwordTextField.leftViewMode = UITextField.ViewMode.always
        passwordTextField.addSubview(passwordImageView)
        
        let passwordPaddingView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: self.emailTextField.frame.height))
        passwordTextField.leftView = passwordPaddingView
        topViewFirst.addSubview(passwordTextField)
        
        //Login Button
        let loginImage = UIImage(named: "Login")
        signupButton.frame = CGRect(x: newTopViewSecond.frame.size.width-60, y: newTopViewSecond.frame.size.height-60, width: 50, height: 50)
        signupButton.backgroundColor = UIColor.black
        signupButton.setImage(loginImage, for: .normal)
        signupButton.clipsToBounds = true
        signupButton.layer.cornerRadius = signupButton.frame.width / 2
        newTopViewSecond.addSubview(signupButton)
        
        self.intialView.addSubview(newTopViewSecond)
        
        //Don't have an account label
        notUser.frame = CGRect(x: 20, y: newBottomViewFirst.frame.height-30, width: newBottomViewFirst.frame.width-20, height: 20)
        notUser.textAlignment = .center
        notUser.font = UIFont(name: notUser.font.fontName, size: 14)
        notUser.text = "Already have An Account"
        notUser.textColor = UIColor.black
        newBottomViewFirst.addSubview(notUser)
        
        //Login Button
        loginButton.frame = CGRect(x: 20, y: bottomViewSecond.frame.size.height-60, width: bottomViewSecond.frame.size.width - 40, height: 50)
        loginButton.setTitle("LOGIN", for: .normal)
        loginButton.backgroundColor = UIColor.black
        loginButton.clipsToBounds = true
        loginButton.layer.cornerRadius = 25
        bottomViewSecond.addSubview(loginButton)
        
        self.intialView.addSubview(newBottomViewFirst)
        
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if UIDevice.current.orientation.isLandscape {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.newTopViewSecond.removeFromSuperview()
                self.newBottomViewFirst.removeFromSuperview()
                self.ViewSetup()
                self.topViewSetup()
            }
            
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.newBottomViewFirst.removeFromSuperview()
                self.newTopViewSecond.removeFromSuperview()
                self.ViewSetup()
                self.topViewSetup()
                
            }
        }
    }
    
    @IBAction func tapGesture(_ sender: UITapGestureRecognizer) {
        if emailTextField.isFirstResponder{
            emailTextField.resignFirstResponder()
        }else{
            passwordTextField.resignFirstResponder()
        }
    }
    
    @objc func signUpButtonPressed(_ sender: UIButton){
        
    }
    
    @objc func logInButtonPressed(_ sender: UIButton){
        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "Login") as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
