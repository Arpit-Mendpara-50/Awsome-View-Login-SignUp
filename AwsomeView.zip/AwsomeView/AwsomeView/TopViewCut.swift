//
//  DemoView.swift
//  AwsomeView
//
//  Created by Arpit on 01/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import UIKit

class TopViewCut: UIView {

    var line: UIBezierPath!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.white
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func createTriangle() {
        line = UIBezierPath()
        
        line.move(to: CGPoint(x: 0, y: 45))
        line.addLine(to: CGPoint(x: self.frame.size.width-30, y: self.frame.size.height))
        line.addLine(to: CGPoint(x: 0.0, y: self.frame.size.height))

        line.close()

    }
    

    override func draw(_ rect: CGRect) {
        
        self.createTriangle()
        
        // Specify the fill color and apply it to the path.
        UIColor.black.setFill()
        line.fill()
        // Specify a border (stroke) color.
        UIColor.black.setStroke()
        line.stroke()
    }
    

}
