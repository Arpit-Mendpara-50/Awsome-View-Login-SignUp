//
//  DownSliderViewController.swift
//  AwsomeView
//
//  Created by Arpit on 18/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import UIKit

class DownSliderViewController: UIViewController {

    
    @IBOutlet weak var sliderViewHeight: NSLayoutConstraint!
    var i = 1
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func swipeUp(_ sender: UISwipeGestureRecognizer) {
        
    }
    @IBAction func panPerfomed(_ sender: UIPanGestureRecognizer) {
        
        if sender.state == .began || sender.state == .changed{
            
            let translation = sender.translation(in: self.view).y
            print(translation)
            if translation<0{
                //if sliderViewHeight.constant > 80{
                if sliderViewHeight.constant >= 90 && sliderViewHeight.constant < 300{
                    UIView.animate(withDuration: 0.2, animations:{

                        self.sliderViewHeight.constant -= translation / 20
                        self.view.layoutIfNeeded()
                    } )
            }
                //}
            }
            else {
                
                if sliderViewHeight.constant >= 90 && sliderViewHeight.constant <= 300{
                UIView.animate(withDuration: 0.2, animations:{

                    self.sliderViewHeight.constant -= translation / 20
                    self.view.layoutIfNeeded()
                } )
            }
        }
        }
        if sender.state == .ended{
            print("last:",sliderViewHeight.constant)
            if sliderViewHeight.constant > 110 && sliderViewHeight.constant < 130{
                UIView.animate(withDuration: 0.2, animations:{
                    
                    self.sliderViewHeight.constant = 300
                    self.view.layoutIfNeeded()
                } )
            }
            if sliderViewHeight.constant > 260 && sliderViewHeight.constant < 280{
                UIView.animate(withDuration: 0.2, animations:{
                    
                    self.sliderViewHeight.constant = 90
                    self.view.layoutIfNeeded()
                } )
            }
            if sliderViewHeight.constant < 90{
                sliderViewHeight.constant = 90
            }
            else if sliderViewHeight.constant > 300{
                sliderViewHeight.constant = 300
            }
        }
    }
    
    @IBAction func onTap(_ sender: UITapGestureRecognizer) {
        UIView.animate(withDuration: 0.2, animations:{
            
            self.sliderViewHeight.constant = 90
            self.view.layoutIfNeeded()
        } )
    }

}
