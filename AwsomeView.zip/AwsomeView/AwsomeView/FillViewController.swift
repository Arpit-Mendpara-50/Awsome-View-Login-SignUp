//
//  FillViewController.swift
//  AwsomeView
//
//  Created by Arpit on 09/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import UIKit

class FillViewController: UIViewController {

    @IBOutlet weak var staticView: UIView!
    @IBOutlet weak var riseView: UIView!
    @IBOutlet weak var viewHeight: NSLayoutConstraint!
    var flag = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        

        // Do any additional setup after loading the view.
        //let view1 = getDynamicItemQty()
        //view.addSubview(view1)
    }
    @IBAction func clickButtonPressed(_ sender: UIButton) {
        
            
            UIView.animate(withDuration: 2, animations: {
                self.riseView.frame = CGRect(x: 0, y: 0, width: self.staticView.frame.width, height: self.staticView.frame.height)
            }, completion: { (true) in
                UIView.animate(withDuration: 2, animations: {
                    if self.flag == 1{
                        self.riseView.frame = CGRect(x: 0, y: self.staticView.frame.height, width: 0, height: 0)
                        self.flag = 0
                    }else{
                        self.riseView.frame = CGRect(x: self.staticView.frame.width, y: self.staticView.frame.height, width: 0, height: 0)
                        self.flag = 1
                    }
                    
                })
            })
    }
    
//
//    func getDynamicItemQty() -> UIView {
//
//        let View = UIView(frame: CGRect(x: 0,y: 0,width: 200,height: 200))
//
//        let circlePath =
//            UIBezierPath(arcCenter: CGPoint(x: 100,y: 100), radius: CGFloat(90), startAngle: CGFloat(9.4), endAngle:CGFloat(0), clockwise: false)
//
//        let shapeLayer = CAShapeLayer()
//        shapeLayer.path = circlePath.cgPath
//
//
//        //shapeLayer.fillRule = kCAFillRuleEvenOdd
//        //change the fill color
//        shapeLayer.fillColor = UIColor.brown.cgColor
//        //you can change the stroke color
//        shapeLayer.strokeColor = UIColor.blue.cgColor
//        //you can change the line width
//        shapeLayer.lineWidth = 10
//
//        View.layer.addSublayer(shapeLayer)
//
//        return View
//
//    }
}
