//
//  BottomViewCut.swift
//  AwsomeView
//
//  Created by Arpit on 07/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import UIKit

class BottomViewCut: UIView {

    var line: UIBezierPath!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.white
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func createTriangle() {
        line = UIBezierPath()
        
        line.move(to: CGPoint(x: 30, y: 0))
        line.addLine(to: CGPoint(x: self.frame.size.width, y: 0))
        line.addLine(to: CGPoint(x: self.frame.size.width, y: self.frame.size.height-40))
        
        line.close()
        
    }
    
    
    override func draw(_ rect: CGRect) {
        
        self.createTriangle()
        
        // Specify the fill color and apply it to the path.
        UIColor.black.setFill()
        line.fill()
        // Specify a border (stroke) color.
        UIColor.black.setStroke()
        line.stroke()
    }

}
